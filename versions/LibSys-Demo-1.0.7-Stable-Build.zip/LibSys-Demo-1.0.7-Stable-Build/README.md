# LibSys Backend — Setup Guide
**C# ASP.NET Core API + MySQL (XAMPP) + ClosedXML Reports**

---

## What's in this package

```
LibSys-Backend/
├── libsys_db.sql              ← Run this in MySQL Workbench first
├── app.js                     ← Replace your old app.js with this
└── LibSys.API/
    ├── LibSys.API.csproj      ← Project file (NuGet packages)
    ├── appsettings.json       ← Database connection string
    ├── Program.cs             ← App startup
    ├── Data/
    │   └── DbContext.cs       ← MySQL connection factory
    ├── Models/
    │   └── LibSysModels.cs    ← C# classes matching DB tables
    └── Controllers/
        ├── CategoriesController.cs
        ├── AuthorsController.cs
        ├── BooksController.cs
        ├── MembersController.cs
        ├── LoansController.cs
        └── ReportsController.cs  ← Excel downloads via ClosedXML
```

---

## Step 1 — Prerequisites

Install these if you haven't already:

| Tool | Where | Why |
|------|-------|-----|
| XAMPP | https://apachefriends.org | Runs MySQL locally |
| .NET 8 SDK | https://dotnet.microsoft.com/download | Runs the C# API |
| MySQL Workbench | https://dev.mysql.com/downloads/workbench/ | Manages the DB visually |

---

## Step 2 — Set up the database

1. Open **XAMPP Control Panel** → click **Start** next to MySQL
2. Open **MySQL Workbench** → connect to `localhost:3306` (user: `root`, no password)
3. Go to **File → Open SQL Script** → select `libsys_db.sql`
4. Click the **lightning bolt** (Execute All)
5. You should see `libsys_db` appear in the left panel with all tables and data

---

## Step 3 — Run the C# API

Open a terminal in the `LibSys.API/` folder and run:

```bash
# Download NuGet packages (first time only)
dotnet restore

# Start the API server
dotnet run
```

You should see:
```
info: Now listening on: http://localhost:5000
```

Open your browser to **http://localhost:5000/swagger** to see all
available API endpoints and test them interactively.

---

## Step 4 — Update your frontend

Replace the old `app.js` in your HTML folder with the new `app.js`
from this package.

The new `app.js` uses `fetch()` to call the API instead of the
hardcoded `DB` object. Everything else in your HTML files stays the same.

**Make sure the API is running before opening any HTML page.**

---

## Step 5 — Excel Reports

In `reports.html`, the download buttons should call:

```javascript
// Replace the old printReport() calls with:
onclick="downloadReport('loans')"
onclick="downloadReport('overdue')"
onclick="downloadReport('inventory')"
onclick="downloadReport('fines')"
onclick="downloadReport('members')"
```

Each button calls `window.open('http://localhost:5000/api/reports/TYPE')`
which triggers an Excel file download from the C# API.

---

## API Endpoints Reference

```
── Categories ──────────────────────────────────────────
GET    /api/categories          List all
GET    /api/categories/{id}     Get one
POST   /api/categories          Create
PUT    /api/categories/{id}     Update

── Authors ─────────────────────────────────────────────
GET    /api/authors             List all
GET    /api/authors/{id}        Get one
POST   /api/authors             Create
PUT    /api/authors/{id}        Update

── Books ────────────────────────────────────────────────
GET    /api/books               List all (with author & category names)
GET    /api/books/{id}          Get one
POST   /api/books               Create
PUT    /api/books/{id}          Update

── Members ─────────────────────────────────────────────
GET    /api/members             List all
GET    /api/members/{id}        Get one
POST   /api/members             Register
PUT    /api/members/{id}        Update

── Loans ────────────────────────────────────────────────
GET    /api/loans               List all (with member & book names)
GET    /api/loans/{id}          Get one
POST   /api/loans               Create loan
POST   /api/loans/{id}/return   Process return + fine calculation
DELETE /api/loans/{id}          Delete returned record

── Reports (Excel downloads) ───────────────────────────
GET    /api/reports/loans       Loans Summary.xlsx
GET    /api/reports/overdue     Overdue Report.xlsx
GET    /api/reports/inventory   Books Inventory.xlsx
GET    /api/reports/fines       Fines Report.xlsx
GET    /api/reports/members     Members Report.xlsx
```

---

## Troubleshooting

**"Cannot reach the API server"** toast in the browser
→ Make sure `dotnet run` is running in the LibSys.API folder

**MySQL connection error on startup**
→ Make sure XAMPP MySQL is started
→ Check appsettings.json — if you set a MySQL password, add it to `Password=`

**CORS error in browser console**
→ The API allows all origins by default. If you still see CORS errors,
  make sure you're calling `http://localhost:5000` not `https://localhost:5001`

**Excel file doesn't download**
→ Try opening `http://localhost:5000/api/reports/loans` directly in the browser
→ You should see a download dialog

---

## How the pieces talk to each other

```
┌─────────────────────┐
│  Your HTML/CSS/JS   │  (your existing frontend files)
│  runs in browser    │
└────────┬────────────┘
         │ fetch('http://localhost:5000/api/...')
         ▼
┌─────────────────────┐
│  C# ASP.NET Core    │  dotnet run  (port 5000)
│  Web API            │
│  - Controllers      │  handle HTTP requests
│  - Dapper           │  maps SQL → C# objects
│  - ClosedXML        │  generates Excel files
└────────┬────────────┘
         │ MySql.Data connector
         ▼
┌─────────────────────┐
│  MySQL (XAMPP)      │  port 3306
│  libsys_db          │
│  - categories       │
│  - authors          │
│  - books            │
│  - members          │
│  - loans            │
└─────────────────────┘
         ↕
┌─────────────────────┐
│  MySQL Workbench    │  visual DB management
└─────────────────────┘
```
