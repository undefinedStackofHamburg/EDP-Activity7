// ── AUTH GUARD ──────────────────────────────────────────────────────────────
// In a real app this would check a session token. For demo, we just allow it.
// Redirect to login if not "authenticated" (using sessionStorage flag).
(function() {
  if (!sessionStorage.getItem('libsys_auth') && !window.location.pathname.endsWith('index.html') && window.location.pathname !== '/' && !window.location.pathname.endsWith('/')) {
    // Allow through in demo; in production: window.location.href = 'index.html';
  }
  sessionStorage.setItem('libsys_auth', '1');
})();

// ── PAGE MAP ────────────────────────────────────────────────────────────────
const PAGES = {
  dashboard:  { file: 'dashboard.html',  title: 'Dashboard' },
  loans:      { file: 'loans.html',      title: 'Loans' },
  books:      { file: 'books.html',      title: 'Books' },
  authors:    { file: 'authors.html',    title: 'Authors' },
  categories: { file: 'categories.html', title: 'Categories' },
  members:    { file: 'members.html',    title: 'Members' },
  reports:    { file: 'reports.html',    title: 'Reports' },
  about:      { file: 'about.html',      title: 'About' },
};

// ── DETECT CURRENT PAGE ─────────────────────────────────────────────────────
const _filename = window.location.pathname.split('/').pop().replace('.html', '') || 'dashboard';
const CURRENT_PAGE = Object.keys(PAGES).includes(_filename) ? _filename : 'dashboard';

// ── INJECT SIDEBAR + TOPBAR ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Mark active nav item
  document.querySelectorAll('.nav-item[data-page]').forEach(el => {
    el.classList.toggle('active', el.dataset.page === CURRENT_PAGE);
  });

  // Set topbar title
  const titleEl = document.getElementById('topbar-title');
  if (titleEl) titleEl.textContent = PAGES[CURRENT_PAGE]?.title || 'LibSys';

  // Set document title
  document.title = `LibSys — ${PAGES[CURRENT_PAGE]?.title || 'App'}`;

  // Sidebar nav clicks → navigate to file
  document.querySelectorAll('.nav-item[data-page]').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      const page = el.dataset.page;
      if (page && PAGES[page]) window.location.href = PAGES[page].file;
    });
  });

  // Sidebar toggle
  document.getElementById('sidebar-toggle')?.addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('collapsed');
  });

  // Logout
  document.getElementById('logout-btn')?.addEventListener('click', () => {
    sessionStorage.removeItem('libsys_auth');
    window.location.href = 'index.html';
  });

  // Toast container must exist
  if (!document.getElementById('toast-container')) {
    const tc = document.createElement('div');
    tc.className = 'toast-container';
    tc.id = 'toast-container';
    document.body.appendChild(tc);
  }

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });
});

// ── NAVIGATE HELPER (cross-page) ────────────────────────────────────────────
function navigateTo(page) {
  if (PAGES[page]) window.location.href = PAGES[page].file;
}

// ── SIDEBAR TOGGLE ───────────────────────────────────────────────────────────
function toggleSidebar() {
  document.querySelector('.sidebar').classList.toggle('collapsed');
}

// ── TOAST ────────────────────────────────────────────────────────────────────
function toast(msg, type = 'success') {
  const icons = { success: '✓', error: '✕', warn: '⚠' };
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span style="font-size:1rem">${icons[type] || 'ℹ'}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── MODAL ────────────────────────────────────────────────────────────────────
function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
