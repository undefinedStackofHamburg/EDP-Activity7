// ============================================================
//  Controllers/ReportsController.cs
//  ─────────────────────────────────
//  What is this?
//  This controller generates Excel (.xlsx) files using ClosedXML
//  and sends them directly to the browser as a download.
//
//  ENDPOINTS:
//  GET /api/reports/loans      → downloads Loans Summary.xlsx
//  GET /api/reports/overdue    → downloads Overdue Report.xlsx
//  GET /api/reports/inventory  → downloads Books Inventory.xlsx
//  GET /api/reports/fines      → downloads Fines Report.xlsx
//  GET /api/reports/members    → downloads Members Report.xlsx
//
//  HOW CLOSEDXML WORKS:
//  1. Create a Workbook (the whole .xlsx file)
//  2. Get a Worksheet (a tab/sheet inside)
//  3. Write values to cells using ws.Cell(row, col).Value = ...
//  4. Style cells with .Style.Font, .Fill, .Alignment, etc.
//  5. Stream the file as bytes to the HTTP response
//     → browser shows "Save As" dialog
// ============================================================

using ClosedXML.Excel;
using Dapper;
using LibSys.API.Data;
using LibSys.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace LibSys.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly LibSysDbContext _db;

    // Brand colors for Excel styling (orange-punch theme)
    private static readonly XLColor AccentOrange = XLColor.FromHtml("#E8621A");
    private static readonly XLColor HeaderBg     = XLColor.FromHtml("#FDF0E6");
    private static readonly XLColor LightBorder  = XLColor.FromHtml("#F0D9C4");
    private static readonly XLColor White         = XLColor.White;

    public ReportsController(LibSysDbContext db) => _db = db;

    // ────────────────────────────────────────────────────────
    //  SHARED HELPERS
    // ────────────────────────────────────────────────────────

    // Styles the top header row of a report sheet
    private static void StyleHeaderRow(IXLWorksheet ws, int colCount, string reportTitle)
    {
        // Row 1: Report title
        var titleCell = ws.Cell(1, 1);
        titleCell.Value = reportTitle;
        titleCell.Style.Font.Bold       = true;
        titleCell.Style.Font.FontSize   = 16;
        titleCell.Style.Font.FontColor  = AccentOrange;
        ws.Range(1, 1, 1, colCount).Merge(); // merge across columns

        // Row 2: Generated date
        ws.Cell(2, 1).Value = $"Generated: {DateTime.Now:MMMM dd, yyyy hh:mm tt}";
        ws.Cell(2, 1).Style.Font.FontColor = XLColor.Gray;
        ws.Cell(2, 1).Style.Font.FontSize  = 9;
        ws.Range(2, 1, 2, colCount).Merge();

        // Row 3: System name
        ws.Cell(3, 1).Value = "LibSys — Library Management System  |  EDP Activity";
        ws.Cell(3, 1).Style.Font.FontColor = XLColor.Gray;
        ws.Cell(3, 1).Style.Font.FontSize  = 9;
        ws.Range(3, 1, 3, colCount).Merge();

        // Blank separator row
        // (row 4 left empty, actual column headers start at row 5)
    }

    // Styles a column header row (the bold row with column names)
    private static void StyleColumnHeaders(IXLRow headerRow)
    {
        foreach (var cell in headerRow.Cells())
        {
            cell.Style.Font.Bold           = true;
            cell.Style.Font.FontColor      = XLColor.White;
            cell.Style.Fill.BackgroundColor = AccentOrange;
            cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            cell.Style.Border.BottomBorder  = XLBorderStyleValues.Medium;
            cell.Style.Border.BottomBorderColor = XLColor.FromHtml("#C04010");
        }
    }

    // Alternates row background colors for readability
    private static void StyleDataRow(IXLRow row, int rowIndex, int colCount)
    {
        var bg = rowIndex % 2 == 0
            ? XLColor.FromHtml("#FDF7F2")  // light cream
            : XLColor.White;

        for (int c = 1; c <= colCount; c++)
        {
            row.Cell(c).Style.Fill.BackgroundColor = bg;
            row.Cell(c).Style.Border.BottomBorder  = XLBorderStyleValues.Thin;
            row.Cell(c).Style.Border.BottomBorderColor = LightBorder;
        }
    }

    // Finalizes the sheet: auto-fit columns, freeze header rows
    private static void FinalizeSheet(IXLWorksheet ws, int colCount)
    {
        ws.Columns(1, colCount).AdjustToContents();
        ws.SheetView.FreezeRows(5); // freeze title + column headers
        ws.PageSetup.PageOrientation = XLPageOrientation.Landscape;
        ws.PageSetup.FitToPages(1, 0); // fit width to 1 page when printing
    }

    // Helper to stream the workbook as a file download
    private FileContentResult ExcelFile(XLWorkbook wb, string filename)
    {
        using var stream = new MemoryStream();
        wb.SaveAs(stream);
        var bytes = stream.ToArray();

        // "application/vnd.openxmlformats..." is the MIME type for .xlsx
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename);
    }

    // ── GET /api/reports/loans ───────────────────────────────
    [HttpGet("loans")]
    public async Task<IActionResult> LoansReport()
    {
        using var conn = _db.CreateConnection();

        var loans = (await conn.QueryAsync<Loan>(@"
            SELECT l.id, l.loan_date AS LoanDate, l.due_date AS DueDate,
                   l.return_date AS ReturnDate, l.fine_amount AS FineAmount, l.status,
                   CONCAT(m.first_name, ' ', m.last_name) AS MemberName,
                   b.title AS BookTitle
            FROM loans l
            JOIN members m ON m.id = l.member_id
            JOIN books   b ON b.id = l.book_id
            ORDER BY l.id")).ToList();

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Loans Summary");

        // ── Header block ──
        StyleHeaderRow(ws, 8, "LibSys — Loans Summary Report");

        // ── Column headers (row 5) ──
        var headers = new[] { "#", "Member", "Book", "Loan Date", "Due Date", "Return Date", "Status", "Fine (₱)" };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(5, i + 1).Value = headers[i];
        StyleColumnHeaders(ws.Row(5));

        // ── Data rows (start row 6) ──
        int row = 6;
        foreach (var l in loans)
        {
            ws.Cell(row, 1).Value = l.Id;
            ws.Cell(row, 2).Value = l.MemberName;
            ws.Cell(row, 3).Value = l.BookTitle;
            ws.Cell(row, 4).Value = l.LoanDate.ToString("MMM dd, yyyy");
            ws.Cell(row, 5).Value = l.DueDate.ToString("MMM dd, yyyy");
            ws.Cell(row, 6).Value = l.ReturnDate.HasValue ? l.ReturnDate.Value.ToString("MMM dd, yyyy") : "—";
            ws.Cell(row, 7).Value = l.Status;
            ws.Cell(row, 8).Value = l.FineAmount;
            ws.Cell(row, 8).Style.NumberFormat.Format = "₱#,##0.00";

            // Color the Status cell
            var statusColor = l.Status switch
            {
                "Active"   => XLColor.FromHtml("#4A7DC0"),
                "Returned" => AccentOrange,
                "Overdue"  => XLColor.FromHtml("#C0392B"),
                _          => XLColor.Gray
            };
            ws.Cell(row, 7).Style.Font.FontColor = statusColor;
            ws.Cell(row, 7).Style.Font.Bold       = true;

            StyleDataRow(ws.Row(row), row, 8);
            row++;
        }

        // ── Summary totals row ──
        ws.Cell(row + 1, 7).Value = "Total Fines:";
        ws.Cell(row + 1, 7).Style.Font.Bold = true;
        ws.Cell(row + 1, 8).Value = loans.Sum(l => l.FineAmount);
        ws.Cell(row + 1, 8).Style.NumberFormat.Format = "₱#,##0.00";
        ws.Cell(row + 1, 8).Style.Font.Bold  = true;
        ws.Cell(row + 1, 8).Style.Font.FontColor = AccentOrange;

        FinalizeSheet(ws, 8);

        return ExcelFile(wb, $"LibSys_Loans_{DateTime.Now:yyyyMMdd}.xlsx");
    }

    // ── GET /api/reports/overdue ─────────────────────────────
    [HttpGet("overdue")]
    public async Task<IActionResult> OverdueReport()
    {
        using var conn = _db.CreateConnection();

        var loans = (await conn.QueryAsync<Loan>(@"
            SELECT l.id, l.due_date AS DueDate, l.fine_amount AS FineAmount, l.status,
                   CONCAT(m.first_name, ' ', m.last_name) AS MemberName,
                   b.title AS BookTitle
            FROM loans l
            JOIN members m ON m.id = l.member_id
            JOIN books   b ON b.id = l.book_id
            WHERE l.status = 'Overdue'
            ORDER BY l.due_date")).ToList();

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Overdue Report");

        StyleHeaderRow(ws, 6, "LibSys — Overdue Loans Report");

        var headers = new[] { "#", "Member", "Book", "Due Date", "Days Late", "Fine (₱)" };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(5, i + 1).Value = headers[i];
        StyleColumnHeaders(ws.Row(5));

        int row = 6;
        foreach (var l in loans)
        {
            var daysLate = (DateTime.Today - l.DueDate.Date).Days;

            ws.Cell(row, 1).Value = l.Id;
            ws.Cell(row, 2).Value = l.MemberName;
            ws.Cell(row, 3).Value = l.BookTitle;
            ws.Cell(row, 4).Value = l.DueDate.ToString("MMM dd, yyyy");
            ws.Cell(row, 4).Style.Font.FontColor = XLColor.FromHtml("#C0392B");
            ws.Cell(row, 5).Value = $"{daysLate} days";
            ws.Cell(row, 5).Style.Font.FontColor = XLColor.FromHtml("#C0392B");
            ws.Cell(row, 5).Style.Font.Bold       = true;
            ws.Cell(row, 6).Value = l.FineAmount;
            ws.Cell(row, 6).Style.NumberFormat.Format = "₱#,##0.00";

            StyleDataRow(ws.Row(row), row, 6);
            row++;
        }

        FinalizeSheet(ws, 6);
        return ExcelFile(wb, $"LibSys_Overdue_{DateTime.Now:yyyyMMdd}.xlsx");
    }

    // ── GET /api/reports/inventory ───────────────────────────
    [HttpGet("inventory")]
    public async Task<IActionResult> InventoryReport()
    {
        using var conn = _db.CreateConnection();

        var books = (await conn.QueryAsync<Book>(@"
            SELECT b.id, b.title, b.isbn, b.year_pub AS YearPub,
                   b.total, b.available,
                   CONCAT(a.first_name, ' ', a.last_name) AS AuthorName,
                   c.name AS CategoryName
            FROM books b
            JOIN authors    a ON a.id = b.author_id
            JOIN categories c ON c.id = b.cat_id
            ORDER BY c.name, b.title")).ToList();

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Books Inventory");

        StyleHeaderRow(ws, 8, "LibSys — Books Inventory Report");

        var headers = new[] { "#", "Title", "Author", "Category", "ISBN", "Year", "Total Copies", "Available" };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(5, i + 1).Value = headers[i];
        StyleColumnHeaders(ws.Row(5));

        int row = 6;
        foreach (var b in books)
        {
            ws.Cell(row, 1).Value = b.Id;
            ws.Cell(row, 2).Value = b.Title;
            ws.Cell(row, 3).Value = b.AuthorName;
            ws.Cell(row, 4).Value = b.CategoryName;
            ws.Cell(row, 5).Value = b.Isbn;
            ws.Cell(row, 6).Value = b.YearPub;
            ws.Cell(row, 7).Value = b.Total;
            ws.Cell(row, 8).Value = b.Available;

            // Color available count: red if 0, amber if low, green if ok
            var availColor = b.Available == 0
                ? XLColor.FromHtml("#C0392B")
                : b.Available < b.Total * 0.3
                    ? XLColor.FromHtml("#D97706")
                    : XLColor.FromHtml("#4A8C3A");

            ws.Cell(row, 8).Style.Font.FontColor = availColor;
            ws.Cell(row, 8).Style.Font.Bold       = true;

            StyleDataRow(ws.Row(row), row, 8);
            row++;
        }

        // Totals row
        ws.Cell(row + 1, 6).Value = "Totals:";
        ws.Cell(row + 1, 6).Style.Font.Bold = true;
        ws.Cell(row + 1, 7).Value = books.Sum(b => b.Total);
        ws.Cell(row + 1, 7).Style.Font.Bold = true;
        ws.Cell(row + 1, 8).Value = books.Sum(b => b.Available);
        ws.Cell(row + 1, 8).Style.Font.Bold      = true;
        ws.Cell(row + 1, 8).Style.Font.FontColor = XLColor.FromHtml("#4A8C3A");

        FinalizeSheet(ws, 8);
        return ExcelFile(wb, $"LibSys_Inventory_{DateTime.Now:yyyyMMdd}.xlsx");
    }

    // ── GET /api/reports/fines ───────────────────────────────
    [HttpGet("fines")]
    public async Task<IActionResult> FinesReport()
    {
        using var conn = _db.CreateConnection();

        var loans = (await conn.QueryAsync<Loan>(@"
            SELECT l.id, l.due_date AS DueDate, l.return_date AS ReturnDate,
                   l.fine_amount AS FineAmount, l.status,
                   CONCAT(m.first_name, ' ', m.last_name) AS MemberName,
                   b.title AS BookTitle
            FROM loans l
            JOIN members m ON m.id = l.member_id
            JOIN books   b ON b.id = l.book_id
            WHERE l.fine_amount > 0
            ORDER BY l.fine_amount DESC")).ToList();

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Fines Report");

        StyleHeaderRow(ws, 7, "LibSys — Fines Collection Report");

        var headers = new[] { "Loan #", "Member", "Book", "Due Date", "Return Date", "Status", "Fine (₱)" };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(5, i + 1).Value = headers[i];
        StyleColumnHeaders(ws.Row(5));

        int row = 6;
        foreach (var l in loans)
        {
            ws.Cell(row, 1).Value = $"#{l.Id}";
            ws.Cell(row, 2).Value = l.MemberName;
            ws.Cell(row, 3).Value = l.BookTitle;
            ws.Cell(row, 4).Value = l.DueDate.ToString("MMM dd, yyyy");
            ws.Cell(row, 5).Value = l.ReturnDate.HasValue ? l.ReturnDate.Value.ToString("MMM dd, yyyy") : "—";
            ws.Cell(row, 6).Value = l.Status;
            ws.Cell(row, 7).Value = l.FineAmount;
            ws.Cell(row, 7).Style.NumberFormat.Format = "₱#,##0.00";
            ws.Cell(row, 7).Style.Font.FontColor       = XLColor.FromHtml("#D97706");
            ws.Cell(row, 7).Style.Font.Bold             = true;

            StyleDataRow(ws.Row(row), row, 7);
            row++;
        }

        // Grand total
        var total = loans.Sum(l => l.FineAmount);
        ws.Cell(row + 1, 6).Value = "Grand Total:";
        ws.Cell(row + 1, 6).Style.Font.Bold = true;
        ws.Cell(row + 1, 7).Value = total;
        ws.Cell(row + 1, 7).Style.NumberFormat.Format = "₱#,##0.00";
        ws.Cell(row + 1, 7).Style.Font.Bold      = true;
        ws.Cell(row + 1, 7).Style.Font.FontSize  = 12;
        ws.Cell(row + 1, 7).Style.Font.FontColor = AccentOrange;

        FinalizeSheet(ws, 7);
        return ExcelFile(wb, $"LibSys_Fines_{DateTime.Now:yyyyMMdd}.xlsx");
    }

    // ── GET /api/reports/members ─────────────────────────────
    [HttpGet("members")]
    public async Task<IActionResult> MembersReport()
    {
        using var conn = _db.CreateConnection();

        var members = (await conn.QueryAsync<Member>(@"
            SELECT id, first_name AS FirstName, last_name AS LastName,
                   phone, membership_date AS MembershipDate, status
            FROM members
            ORDER BY status, last_name")).ToList();

        // Also fetch loan counts per member
        var loanCounts = (await conn.QueryAsync<dynamic>(
            "SELECT member_id, COUNT(*) AS total FROM loans GROUP BY member_id"))
            .ToDictionary(r => (int)r.member_id, r => (int)r.total);

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Members Report");

        StyleHeaderRow(ws, 7, "LibSys — Members Report");

        var headers = new[] { "#", "Full Name", "Phone", "Member Since", "Status", "Total Loans", "Active Loans" };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(5, i + 1).Value = headers[i];
        StyleColumnHeaders(ws.Row(5));

        // Preload active loan counts
        var activeLoans = (await conn.QueryAsync<dynamic>(
            "SELECT member_id, COUNT(*) AS cnt FROM loans WHERE status='Active' GROUP BY member_id"))
            .ToDictionary(r => (int)r.member_id, r => (int)r.cnt);

        int row = 6;
        foreach (var m in members)
        {
            loanCounts.TryGetValue(m.Id, out int total);
            activeLoans.TryGetValue(m.Id, out int active);

            ws.Cell(row, 1).Value = m.Id;
            ws.Cell(row, 2).Value = m.FullName;
            ws.Cell(row, 3).Value = m.Phone;
            ws.Cell(row, 4).Value = m.MembershipDate.ToString("MMM dd, yyyy");
            ws.Cell(row, 5).Value = m.Status;

            // Color status
            var statusColor = m.Status switch
            {
                "Active"    => XLColor.FromHtml("#4A8C3A"),
                "Suspended" => XLColor.FromHtml("#D97706"),
                "Expired"   => XLColor.Gray,
                _           => XLColor.Black
            };
            ws.Cell(row, 5).Style.Font.FontColor = statusColor;
            ws.Cell(row, 5).Style.Font.Bold       = true;

            ws.Cell(row, 6).Value = total;
            ws.Cell(row, 7).Value = active;
            if (active > 0)
            {
                ws.Cell(row, 7).Style.Font.FontColor = XLColor.FromHtml("#4A7DC0");
                ws.Cell(row, 7).Style.Font.Bold       = true;
            }

            StyleDataRow(ws.Row(row), row, 7);
            row++;
        }

        FinalizeSheet(ws, 7);
        return ExcelFile(wb, $"LibSys_Members_{DateTime.Now:yyyyMMdd}.xlsx");
    }
}
